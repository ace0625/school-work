
int load_courses(char course_file_name[]);
