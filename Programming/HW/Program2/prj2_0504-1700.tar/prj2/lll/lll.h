class bclass
{
	public:
		bclass();
		bclass(char* a_course_type, int a_course_code, char* a_course_name, int a_course_credit): course_type(a_course_type), course_code(a_course_code), course_name(a_course_name), course_credit(a_course_credit);
		display_bclass();
	protected:
		char* course_type;
		int course_code;
		char* course_name;
		int course_credit;
}

class node: public bclass
{
	public:
		node(); // node constructor
		node(const int index); // node constructor
		~node(); // node destructor
		node *& go_next(); // LLL node move to left
		bool if_next();
		void display();
		int retrieve(const int a_data);
	
	protected:
		node* next;
};

// LLL objects
class lll: public node
{
	public:
		lll(); // LLL constructor
		~lll(); // LLL destructor
		void add(const int a_data);
		void add(node* & head, const int data); // add data at front of LLL
		void remove(const int data);
		void remove(node* & head, const int data); // remove index of data ( in deal datas)
		void display_all(); // display data of LLL
		void display_all(node* head); // display data of LLL
		int remove_all();
		int remove_all(node * & head);
		bool find(const int a_data);

	protected:
		node* head;
};


