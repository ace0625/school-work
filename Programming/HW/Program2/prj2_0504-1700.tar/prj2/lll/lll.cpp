#include <iostream>
#include <cstdlib>
#include "lll.h"
#include "course_input.h"
using namespace std;


// class - base class ****************************
// constructor - bclass for classes' basic data
bclass::bclass()
{}

bclass::bclass(bclass* a_bclass):course_type(a_bclass.course_type),
	course_code(a_bclass.course_code),
	course_name(a_bclass.course_name),
	course_credit(a_bclass.course_credit)
{}

bclass::display_bclass()
{
	cout << "course data *********" << endl;
	cout << "course_type  :" << course_type   << endl;
	cout << "course_code  :" << course_code   << endl;
	cout << "course_name  :" << course_name   << endl;
	cout << "course_credit:" << course_credit << endl << endl;	
}

// class - node ****************************
// constructor - node for a linear linked list
node::node()
{
	next = NULL;
}


node::~node()
{
	cout << "node::~node()" << endl;
}

node::node(bclass* a_bclass): bclass(a_bclass);

node::node(char* a_course_type, int a_course_code, char* a_course_name, int a_course_credit): bclass(a_course_type, a_course_code, a_course_name, a_course_credit)
{}

// node move to next
node *& node::go_next()
{
	return next;
}

bool node::if_next()
{
	if(next) return true;
	else return false;
}

void node::display()
{
	display_bclass();
}

int node::retrieve(const int bclass)
{
	if(data != bclass) return 0;
	data = bclass;
	return 1;
}

// class - lll ****************************
// constructor for lll class
lll::lll()
{
	head = NULL;
}

// destructor for lll class
lll::~lll()
{
	remove_all();
	delete head;
}

void lll::add(const int bclass)
{
	add(head, bclass);
}

void lll::add(node*& head, const bclass)
{
	if(!head) {
		head = new node(bclass);
		head->go_next() = NULL;
		return;
	}
	return add(head->go_next(), bclass);
}

void lll::remove(const int bclass)
{
	if(!head) return;
	node* temp = head;
	while(!head->retrieve(bclass)) {
		temp = head;
		head = head->go_next();
	}
	temp->go_next() = head->go_next();
	delete head;
	head = NULL;	
}

bool lll::find(const int course_type, course_code)
{
	if(retrieve(course_type, course_code)) return true;
	else return false;
}

void lll::display_all()
{
	display_all(head);
}

void lll::display_all(node* head)
{
	if(!head) return;
	
	head->display();
	display_all(head->go_next());
}

int lll::remove_all()
{
	int result = remove_all(head);
	cout << "remove_all: " << result << endl;
	return 1;
}

int lll::remove_all(node * & head)
{
	if(!head) return 0;
	int val = remove_all(head->go_next()) + 1;
	delete head;
	head = NULL;
	return val;	
}


int main()
{
	lll b;
	
	/*
	cout << "\n\n** add **************************" << endl;
	b.add(114);
	b.add(222);
	b.add(131);
	b.add(292);
	b.add(91);
	b.add(28);
	b.add(56);
	b.add(78);
	b.add(135);
	b.add(81);
	b.add(152);
	b.add(111);
	b.add(142);
    b.display_all();
	cout << endl;
	*/
	char course_file_name [] = "course.txt";
	load_courses(b, course_file_name);

	return 0;
}
