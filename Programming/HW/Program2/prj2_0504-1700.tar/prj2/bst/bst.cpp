#include <iostream>
#include <cstdlib>
#include "bst.h"
using namespace std;

// class - node ****************************
// constructor - node for binary search tree
node::node()
{
	left = right = NULL;
}


node::~node()
{
	cout << "node::~node()" << endl;
	delete left;
	delete right;
	left = right = NULL;
}

node::node(const int a_card): card(a_card)
{}

// node move to left
node *& node::go_left()
{
	return left;
}

// node move to right
node *& node::go_right()
{
	return right;
}

bool node::if_left()
{
	if(left) return true;
	else false
}

bool node::if_right()
{
	if(right) return true;
	else false
}

void node::display()
{
	cout << card;
}

int node::get_card()
{
	return card;
}

int node::compare(int a_card)
{
	if(card == a_card)	return 0;
	else if(card > a_card) return -1;
	else return 1;
}

void node::set_card(int a_card)
{
	card = a_card;
}

// check match card 
bool node::match_card(const int a_card)
{
	if(card == a_card) return true;
	else return false;
}

// class - bst ****************************
// constructor for bst class
bst::bst()
{
	root = NULL;
}

// destructor for bst class
bst::~bst()
{
	remove_all();
	delete root;
}

void bst::add(const int a_card)
{
	add(root, a_card);
}

void bst::add(node*& root, const int a_card)
{
	if(!root) {
		root = new node;
		root->set_card(a_card);
		//root->a_card = a_card;
		root->go_left() = root->go_right() = NULL;
	}
	else if(compare(a_card, root->get_card()) < 0)
		add(root->go_left(), a_card);
	else
		add(root->go_right(), a_card);
}

int bst::compare(const int a_card, const int b_card)
{
	if(a_card == b_card)	return 0;
	else if(a_card > b_card) return -1;
	else return 1;
}

void bst::remove(const int a_card)
{
	remove(root, a_card);
}

void bst::remove(node* &root, const int a_card)
{
	if(!root) return;
	
	cout << "a_card:" << a_card << "; get_card():" << root->get_card() << endl;
	if(compare(a_card, root->get_card()) == 0) {
		cout << "test1************" << endl;
		// 1. no child
		if(!root->go_left() && !root->go_right()) {
			delete root;
			root = NULL;
		}
		// 2-1. one child on left
		else if(root->go_left() && !root->go_right()) {
			node* temp = root;
			root = root->go_left();
			delete temp;
		}
		// 2-2. one child on right
		else if(!root->go_left() && root->go_right()) {
			node* temp = root;
			root = root->go_right();
			delete temp;
		}
		// 3. two child
		else {
			// 3.1 
			node* is = root->go_right();
			node* is_pa = root->go_right();
			
			while(is->go_left()) {
				is_pa->set_card(is->get_card());
				is = is->go_left();
			}
			
			// replace data root from IS (inorder successor)
			//root->a_card = is->a_card;
			root->set_card(is->get_card());

			// 3.1 IS has no left child
			if(is == is_pa) {
				root->go_right() = is->go_right();
			}
			else {
				// 3.2 IS has right child
				if(is->go_right())
					is_pa->go_left() = is->go_right();
				else
					is_pa->go_left() = NULL;
			}
			
			delete is;
			is = NULL;

			return;
		}
	}
//	else if(data < root->data) {
	else if(compare(a_card, root->get_card()) < 0) {
		return remove(root->go_left(), a_card);
	}
	else {
		return remove(root->go_right(), a_card);
	}
}

void bst::display_all()
{
	display_all(root);
}

void bst::display_all(node* root)
{
	if(!root) return;

	display_all(root->go_left());
	cout << root->get_card() << ", ";
	display_all(root->go_right());
}

int bst::remove_all()
{
	int result = remove_all(root);
	cout << "remove_all: " << result << endl;
	return 1;
}

int bst::remove_all(node * & root)
{
	if(!root) return 0;
	int val = remove_all(root->go_left()) + remove_all(root->go_right()) + 1;
	delete root;
	root = NULL;
	return val;	
}


int main()
{
	bst b;

	cout << "\n\n** add **************************" << endl;
	b.add(114);
	b.add(222);
	b.add(131);
	b.add(292);
	b.add(91);
	b.add(28);
	b.add(56);
	b.add(78);
	b.add(135);
	b.add(81);
	b.add(152);
	b.add(111);
	b.add(142);
    b.display_all();
	cout << endl;

	int rem = 114;
	cout << "** remove "<< rem << " **************************" << endl;
	b.remove(rem); 
	b.display_all();
	cout << endl;

	return 0;
}
