class node
{
	public:
		node(); // node constructor
		node(const int index); // node constructor
		~node(); // node destructor
		node *& go_left(); // BST node move to left
		node *& go_right(); // BST node move to right
		bool if_left();
		bool if_right();
		void display();
		bool match_card(int a_card);
		void set_card(int a_card);
		int get_card();
		int compare(int a_card);
	
	protected:
		node* left;
		node* right;
		int card;
};

// BST objects
class bst: public node
{
	public:
		bst(); // BST constructor
		~bst(); // BST destructor
		void add(const int a_card);
		void add(node* & root, const int card); // add data at front of BST
		void remove(const int card);
		void remove(node* & root, const int card); // remove index of data ( in deal cards)
		void display_all(); // display data of BST
		void display_all(node* root); // display data of BST
		int compare(const int a_card, const int b_card);
		int remove_all();
		int remove_all(node * & root);

	protected:
		node* root;
};


